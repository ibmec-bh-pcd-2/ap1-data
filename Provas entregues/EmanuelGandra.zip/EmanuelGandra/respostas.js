const linhasMetro = require("./data.js")

//Questao 1
const adicionarParada = () => {
    linhasMetro.find((produto) => produto.id === '202')
    .paradas.push({
        nome: "Terminal Central",
        tipo: "terminal",
        coordenadas: { latitude: -19.912998, longitude: -43.940933 }
      })

}

const removerParada = () => {
    linhasMetro.find((produto) => produto.id === '202')
    .paradas.shift()
}

//Quest2
const PrintarChaves = () => {
    const linha505 = linhasMetro.find((produto) => produto.id === '505')
    .map((metro) => metro.empresaResponsavel)

    for(keys in linha505){
        console.log(`As chaves/propriedades são ${keys}`)
    }
}

const PrintarValores = () => {
    const linha505 = linhasMetro.find((produto) => produto.id === '505')
    .map((metro) => metro.empresaResponsavel)

    console.log(Object.values(linha505))
}


//Quest3
const InserirHorario = () => {
    horarionovo = {
        partida: "05:46",
        chegada: "06:35",
        dias: ["Segunda"]
      }
    linhasMetro.forEach((produto) => produto.horarios.assign(horarionovo,produto.horarios))

}

const RemoverHorario = () => {
    horarionovo = {
        partida: "05:46",
        chegada: "06:35",
        dias: ["Segunda"]
      }
    horarionovo2 = {
        partida: "22:17",
        chegada: "23:06",
        dias: ["Domingo"]
      }
    linhasMetro.forEach((produto) => produto.horarios.shift())

}

const AdicionarHorarioFinal = () => {
    horarionovo2 = {
        partida: "22:17",
        chegada: "23:06",
        dias: ["Domingo"]
      }
    linhasMetro.forEach((produto) => produto.horarios.push(horarionovo2))

}

//Quest4

const tarifas = () => {
    const linhas = linhasMetro.map((produto) => produto.id)
    const tarifas = linhasMetro.map((produto) => produto.tarifa)
    var retorno = []
    for(let i = 0 ; i < linahs.lenght; i++){
    retorno.push(`A tarifa da linha ${linhas[i]} é de R$ ${tarifas[i]}`)
    }
    return retorno
}

//Quest5
const tarifasMaisCaras = () => { 
    return linhasMetro.
    filter((produto) => produto.tarifa > 5)}

//Quest6
const linhaMelhorAvaliada = () => {
    const LinhaBemAvaliada = linhasMetro.find((produto) => produto.avaliacao >= 4.5).
    map((produto2) => produto2.nomeLinha)
    const Avaliaçao = inhasMetro.find((produto) => produto.avaliacao >= 4.5).
    map((produto2) => produto2.avaliacao)
    return `A linha ${LinhaBemAvaliada} possui a avaliação de ${Avaliaçao}`
}

module export = { tarifas, linhaMelhorAvaliada, tarifasMaisCaras}