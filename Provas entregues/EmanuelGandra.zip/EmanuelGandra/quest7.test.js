//QUEST7

const {tarifas, linhaMelhorAvaliada, tarifasMaisCaras} = require("./respostas.js")
const linhasMetro = require("./data.js")

ARRAY_TESTE_TARIFAS = [`A tarifa da linha 101 é de R$ 4.50`, `A tarifa da linha 303 é de R$ 4.80`,`A tarifa da linha 202 é de R$ 5.00`,`A tarifa da linha 404 é de R$ 6.00`,`A tarifa da linha 505 é de R$ 3.90`]
TESTE_LINHAMELHORAVALIADA =`A linha Bairro Industrial - Praça da Estação possui a avaliação de 4.5`
ARRAY_TESTE_VAZIO = []


//LETRA A)
describe("Verificar se a função tarifas é do tipo function",()=>
        Test(expect(typeof(tarifas())) === toBe(Function))
);

//LETRA B)
describe("Verificar se a função tarifas retorna o Array Correto",()=>
        Test(expect(tarifas()) === toStrictEqual(ARRAY_TESTE_TARIFAS))
);

//LETRA C)
describe("Verificar se linhaMelhorAvaliada retorna a primeira linha com valor acima de 4.5 no formato correto",()=>
        Test(expect(linhaMelhorAvaliada()) === toStrictEqual(TESTE_LINHAMELHORAVALIADA))
);

//LETRA D)
describe("Verificar se tarifasMaisCaras retornaria um array vazio quando não houvesse linhas com tarifas superiores a R$5,00",()=>
        linhasMetro = linhasMetro.map((produto) => produto.tarifa > 5).
        forEach((produto2) => produto2.tarifa = 0),
        Test(expect(tarifasMaisCaras()) === toStrictEqual(ARRAY_TESTE_VAZIO))
); 


